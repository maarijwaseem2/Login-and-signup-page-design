const formOpenBtn = document.querySelector("#form-open"),
home = document.querySelector(".home"),
formContainer = document.querySelector(".form-container"),
formCloseBtn = document.querySelector(".form-close"),
signupbtn = document.querySelector("#signup"),
loginbtn = document.querySelector("#login"),
pwshowHide = document.querySelector(".pw_hidden");

formOpenBtn.addEventListener("click",()=> home.classList.add("show"));
formCloseBtn.addEventListener("click",()=> home.classList.remove("show"));

pwshowHide.forEach((icon)=>{
    icon.addEventListener("click",()=>{
        let getpwinput =icon.parentElement.querySelector(".input");
        if(getpwinput.type === "password"){
            getpwinput.type = "text";
            icon.classList.replace("uil-eye-slash","uil-eye");
        }
        else{
            getpwinput.type = "password";
            icon.classList.replace("uil-eye","uil-eye-slash");
        }
    });
});

signupbtn.addEventListener("click",(e)=>{
    e.preventDefault();
    formContainer.classList.add("active");
}); 
loginbtn.addEventListener("click",(e)=>{
    e.preventDefault();
    formContainer.classList.remove("active");
});
